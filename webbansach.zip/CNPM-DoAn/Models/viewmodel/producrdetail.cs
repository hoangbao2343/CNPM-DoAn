﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CNPM_DoAn.Models.viewmodel
{
    public class producrdetail : Controller
    {
        // GET: homeproduct
        public ActionResult Index()
        {
            return View();
        }
    }
}